
public class Interface {

}
