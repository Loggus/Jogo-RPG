
public class Jogador {

}
