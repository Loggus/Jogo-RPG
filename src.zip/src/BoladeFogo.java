
public class BoladeFogo {

}
