
public class Mago {

}
