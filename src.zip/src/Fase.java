
public class Fase {

}
